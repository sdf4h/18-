from adult.configs import *
from adult import db
import requests
import time
import json

url_dev = "https://api.telegram.org/bot{0}/sendMessage".format(dev_token)
url = "https://api.telegram.org/bot{0}/sendMessage".format(bot_token)
url_del = 'https://api.telegram.org/bot{0}/deleteMessage'.format(bot_token)
url_photo = 'https://api.telegram.org/bot{0}/sendPhoto'.format(bot_token)
url_photo_download = 'https://api.telegram.org/bot{0}/getFIle'.format(bot_token)
url_end_photo = 'https://api.telegram.org/file/bot{0}/'.format(bot_token)

# отправка сообщения в телеграмм по chat_id
def message_user(text, chat_id):
	message_data = {
	'chat_id': chat_id,
	'text': text,
	'parse_mode':'HTML'
	}
	try:
		requests.post(url, data=message_data)
	except:
		return	

# отправка сообщение в телеграмм дева
def message_dev(text):
	for i in dev_chat_id:
		message_data = {
		'chat_id': i,
		'text': text,
		'parse_mode':'HTML'
		}
		try:
			requests.post(url_dev, data=message_data)
		except:
			return

# отправка сообщения от парня девушке
def message_to_girl(text, chat_id):
	message_data = {
	'chat_id': chat_id,
	'text': text,
	'parse_mode':'HTML'
	}
	try:
		requests.post(url, data=message_data)
	except:
		return

# отправка сообщения всем девушкам
def message_to_all_girl(text):
	profiles = db.sql_db().select_profiles()
	if profiles is False:
		return
	for chat in profiles:
		if chat["chat_id"] is None:
			continue
		message_data = {
		'chat_id': chat["chat_id"],
		'text': text,
		'parse_mode':'HTML'
		}
		try:
			requests.post(url, data=message_data)
			time.sleep(0.3)
		except:
			return	

# отправка сообщение от пользователя админу
def message_to_admin(text, chat_id):
	message_data = {
	'chat_id': chat_id,
	'text': text,
	'parse_mode':'HTML'
	}
	try:
		requests.post(url_dev, data=message_data)
	except:
		return

# удаление сообщения в чате
def delete_mes(chat_id, mes_id):
	message_data = {
	'chat_id': chat_id,
	'message_id': mes_id
	}
	try:
		requests.post(url_del, data=message_data)
	except:
		return

def send_photo(chat_id, photo):
	message_data = {
		'chat_id': chat_id
	}
	files = {
		'photo': photo
	}
	try:
		api = requests.post(url_photo, files=files, data=message_data)
		print(api.text, api.status_code)
	except Exception as e:
		print(e)
		return

# загружаем фото пользователя в базу
def get_photo(file_id):
	message_data = {
		'file_id': file_id  # в функцию передается ИД фотографии, которое берется из запроса
	}
	try:
		api = requests.post(url_photo_download, data=message_data)  # делаем запрос в телегу, чтобы вытащить путь до фотки
		data = json.loads(api.text)
		file_path = data["result"]["file_path"]						# достаем путь до фотки
		url = "{url}{path}".format(url=url_end_photo, path=file_path)	# формируем ссылку до фотки
		api_photo = requests.get(url)								# считываем фотку и возвращаем
		return api_photo.content
	except Exception as e:
		print(e)
		return False
from adult.configs import bot
from adult.actions import delete_mes, send_photo
from adult import text, keyboard, db
from datetime import datetime
import time

# выводим список кнопок с городами анкет
def select_country(data, chat, update_id):
    country = data.split("_")[-1]
    city_keys = keyboard.search_profile_city(country) # клавиши анкет "по городам"
    delete_mes(chat_id=chat, mes_id=update_id)		  # удаляем предыдущее сообщение
    if city_keys is False:	# если кнопок нет, то выводим ошибку
        bot.send_message(chat_id=chat, text=text.text_ERROR_COMMAND, parse_mode='HTML')
        return
    bot.send_message(chat_id=chat, text="Выберете город, где вам удобно будет провести время", parse_mode='HTML', reply_markup=city_keys)

# выводим список кнопок с анкетами девушек
def select_city(data, chat, update_id):
	city = data.split("_")[-1]
	girl_keys = keyboard.search_profile_girls(city)
	delete_mes(chat_id=chat, mes_id=update_id) # удаляем предыдущее сообщение
	if girl_keys is False:
		bot.send_message(chat_id=chat, text=text.text_ERROR_COMMAND, parse_mode='HTML')
		return
	bot.send_message(chat_id=chat, text="Выберете девушку, с которой хотите встретиться и провести время", parse_mode='HTML', reply_markup=girl_keys)

# выводим сообщение с анкетой при поиске анкет
def select_girl(data, chat, update_id):
	data = data.split("_")
	keys = data[0]
	girl_chat = data[-1] # вытаскиваем чат_ИД девушки
	profile = db.sql_db().select_profile_chat_id(girl_chat) # вытаскиваем из базы данные девушки по чат_ИД
	if profile is False:
		# если в базе ничего нет, то выводим сообщение об ошибке
		bot.send_message(chat_id=chat, text=text.text_ERROR_COMMAND, parse_mode='HTML')
		return
	
	delete_mes(chat_id=chat, mes_id=update_id) # удаляем предыдущее сообщение
	create_time = profile["time"]
	if create_time is not None:
		create_time = datetime.utcfromtimestamp(create_time).strftime('%Y-%m-%d')
	# формируем текст сообщения с анкетой
	end_text = text.text_GIRL_PROFILE.format(
		name=search_none(profile["name"]),
		age=profile["age"],
		height=profile["height"],
		weight=profile["weight"],
		hour=profile["hour"],
		night=profile["night"],
		city=search_none(profile["city"]),
		country=search_none(profile["country"]),
		edit=create_time
	)
	if profile["foto"] is not None:			# если есть фотография, то отправляем сообщение с ней
		send_photo(chat, profile["foto"])
		time.sleep(0.2)
	if keys == "view":		# если просматривает анкету админ из админки
		end_text += "\nchat_id: <b>{chat_id}</b>".format(chat_id=profile["chat_id"])
		bot.send_message(chat_id=chat, text=end_text, parse_mode='HTML')
		return
	if keys == "moder":		# админ из админки (тож самое что и выше)
		end_text += "\nchat_id: <b>{chat_id}</b>".format(chat_id=profile["chat_id"])
		bot.send_message(chat_id=chat, text=end_text, parse_mode='HTML', reply_markup=keyboard.moder_profile_keyboard(girl_chat))
		return
	views = profile["views"]
	if views is None:
		views = 0
	# добавляем +1 просмотр анкеты
	db.sql_db().update_profile_item(chat_id=girl_chat, item="views", value=views+1)
	bot.send_message(chat_id=chat, text=end_text, parse_mode='HTML', reply_markup=keyboard.girl_profile(chat_id=chat, girl_chat=girl_chat, city=profile["city"]))

# отправляем сообщение девушке от парня
def send_message_to_girl(data, chat, update_id):
	data = data.split("_")
	girl_chat = data[-1]
	key = data[0]
	db.sql_db().update_user_info_item(chat_id=chat, item="message_status", value="girl_%s" % girl_chat)
	if key == "admin":
		bot.send_message(chat_id=chat, text=text.text_MESSAGE_TO_GIRL_KEYBOARD_FROM_ADMIN, parse_mode='HTML')
		return
	bot.send_message(chat_id=chat, text=text.text_MESSAGE_TO_GIRL_KEYBOARD, parse_mode='HTML')

# список анкет для админа
def list_profile_for_admin(chat_id, update_id):
	keys = keyboard.profile_on_moder() 				# смотрим есть ли анкеты на одобрение
	delete_mes(chat_id=chat_id, mes_id=update_id)	# удаляем предыдущее сообщение
	if keys is False:
		bot.send_message(chat_id=chat_id, text="Нет анкет на одобрение. Надо бы пригнать народ в бота!", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
		return
	bot.send_message(chat_id=chat_id, text="Если список пуст, значит он пуст!", parse_mode='HTML', reply_markup=keys)

# жалоба на анкету
def send_claim_girl(data, chat):
	db.sql_db().update_user_info_item(chat_id=chat, item="message_status", value=data)
	bot.send_message(chat_id=chat, text="Введите сообщение администратору", parse_mode='HTML')

# проверяем является ли переменная None, если нет, то делаем первую букву заглавной
def search_none(item):
	if item is not None:
		return item.title()
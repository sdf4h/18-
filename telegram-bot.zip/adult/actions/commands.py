from adult.configs import bot, dev_chat_id
from adult.actions import message_user, message_to_girl, message_to_admin, get_photo, send_photo, message_dev
from adult import text, keyboard, db
from datetime import datetime
import time, random, json

# словаьр шагов при создании анкеты
UPDATE_ITEM = {
    "country": {"text": text.update_profile["city"], "item": "city"},
    "city": {"text": text.update_profile["name"], "item": "name"},
    "name": {"text": text.update_profile["age"], "item": "age"},
    "age": {"text": text.update_profile["height"], "item": "height"},
    "height": {"text": text.update_profile["weight"], "item": "weight"},
    "weight": {"text": text.update_profile["hour"], "item": "hour"},
    "hour": {"text": text.update_profile["night"], "item": "night"},
    "night": {"text": text.update_profile["foto"], "item": "foto"},
}

# отправляем сообщение девушке от парня
def send_message_girl(girl_chat, username, text_mess, chat_id):
	message_to_girl(chat_id=girl_chat, text=text.text_MESSAGE_TO_GIRL.format(username=username, text=text_mess))
	time.sleep(0.3)
	# сообщение парню, что его сообщение для девушки ушло
	message_user(chat_id=chat_id, text="🔔 Ваше сообщение отправлено. Девушка непременно Вам ответит, как только увидит сообщение")
	db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
	time.sleep(0.2)
	# добавляем сообщение в базу
	db.sql_db().insert_messages(user_from=chat_id, user_to=girl_chat, message=text_mess)

# отправляем сообщение администратору
def send_message_admin(text_mess, chat_id, username):
	chat_id_admin = random.choice(dev_chat_id)
	message_to_admin(chat_id=chat_id_admin, text=text.text_MESSAGE_TO_GIRL.format(username=username, text=text_mess))
	time.sleep(0.2)
	# уведомляем, что сообщение администратору улетело
	message_user(chat_id=chat_id, text="🔔 Ваше сообщение отправлено Администратору.")
	db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
	time.sleep(0.2)
	# добавляем сообщение в базу
	db.sql_db().insert_messages(user_from=chat_id, user_to=chat_id_admin, message=text_mess)

# проверка номера телефона
def verify_telephone_number(chat_id, phone):
	verify_tel = db.sql_db().select_profile_by_phone(phone)
	if verify_tel is False:  # если телефона нет в базе, то пробуем добавить данные в базу
		if db.sql_db().insert_new_profile(chat_id=chat_id, phone=phone) is False: # если телефон не удалось добавить в базу
			bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, reply_markup=keyboard.main_keyboard_girl(False))
			return
		#  если телефон удалось добавить в базу, то приветствуем и предлагаем ввести страну
		bot.send_message(chat_id=chat_id, text=text.text_AFTER_VERIFY_PHONE, reply_markup=keyboard.cancel_keyboard())
		db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="country")
		return
	if verify_tel["chat_id"] == chat_id: # если телефон есть в базе, то проверяем совпадает ли чат_ИД пользователя и данных из базы
		bot.send_message(chat_id=chat_id, text=text.text_VERIFY_PHONE_FALSE, reply_markup=keyboard.main_keyboard_girl(False))
		return
	# если не совпадает чат_ИД, то пробуем добавить чат-ИД пользователя к телефону
	if db.sql_db().update_profile_item_tel(tel=phone, item="chat_id", value=chat_id) is False:
		bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, reply_markup=keyboard.main_keyboard_girl(False))
		return		
	bot.send_message(chat_id=chat_id, text=text.text_AFTER_VERIFY_PHONE, reply_markup=keyboard.cancel_keyboard())
	db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="country")

def update_string_item(chat_id, item, value):
	end_value = value.split(" ")[0].lower()
	try:
		end_value = int(end_value)
	except:
		end_value = end_value.lower()
	try:
		if db.sql_db().update_profile_item(chat_id=chat_id, item=item, value=end_value) is False:
			bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, parse_mode='HTML', reply_markup=keyboard.edit_profile())
			return
		bot.send_message(chat_id=chat_id, text=UPDATE_ITEM[item]["text"], parse_mode='HTML', reply_markup=keyboard.cancel_keyboard())
		time.sleep(0.3)
		db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value=UPDATE_ITEM[item]["item"])
	except:
		bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, parse_mode='HTML', reply_markup=keyboard.edit_profile())

# редактирование параметра анкеты
def edit_profile_item(chat_id, item, value):
	end_value = value.split(" ")[0]
	try:
		end_value = int(end_value)
	except:
		pass
	try:
		# пробуем обновить запись в базе данных
		if db.sql_db().update_profile_item(chat_id=chat_id, item=item, value=end_value) is False:
			# если что то пошло не так, то выводим сообщение об ошибке
			bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, parse_mode='HTML', reply_markup=keyboard.edit_profile())
			db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
			return
		# если все ОК, то подтверждаем это сообщением
		bot.send_message(chat_id=chat_id, text="Изменения успешно применены", parse_mode='HTML', reply_markup=keyboard.edit_profile())
		time.sleep(0.3)
		db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
	except:
		bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, parse_mode='HTML', reply_markup=keyboard.edit_profile())
		db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")

# обновление фотографии в анкете
def update_photo(chat_id, file_id):
	photo_bytes = get_photo(file_id)	# берем ИД фотографии из телеграмма
	if photo_bytes is False:			# если вдруг не удалось получить ИД фотографии
		bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, parse_mode='HTML', reply_markup=keyboard.cancel_keyboard())
		db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
		return
	# если не удалось загрузить фото в базу
	if db.sql_db().update_profile_item(chat_id=chat_id, item="foto", value=photo_bytes) is False:
		bot.send_message(chat_id=chat_id, text=text.text_ERROR_COMMAND, parse_mode='HTML', reply_markup=keyboard.cancel_keyboard())
		db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
		return
	# если фотография успешно загружена
	bot.send_message(chat_id=chat_id, text="Фотография загружена.", parse_mode='HTML', reply_markup=keyboard.main_keyboard_girl(True))
	time.sleep(0.3)
	# обновляем статус пользователя
	db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")

# кнопки с пользователями для бана
def command_ban_user(chat_id, data):
	try:
		ban = data.split(" ")[1] # проверка, вдруг админ написал /ban а имя юзера для бана забыл
	except:
		bot.send_message(chat_id=chat_id, text="Не ввел имя пользователя (через пробел)", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
		return
	# пробуем сформировать класвиатуру
	keys = keyboard.ban_users_keyboard(ban)
	if keys is False:
		bot.send_message(chat_id=chat_id, text="Не нашлось совпадений в базе", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
		return
	bot.send_message(chat_id=chat_id, text="Нужно выбрать пользователя", parse_mode='HTML', reply_markup=keys)

# загружаем данные из JSON в базу
def insert_json_data(chat_id, data):
	if "json" in data["mime_type"]:
		try:
			# пробуем вытянуть данные из json файла
			json_data = json.loads(get_photo(data["file_id"]))
		except Exception as e:
			print(e)
			bot.send_message(chat_id=chat_id, text="Не удалось взять данные из файла. Надо глянуть лог", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
			return
		try:
			# вытаскиваем все телефоны из анкет из базы
			db_profiles = db.sql_db().select_profile_telephones()
			if db_profiles is False:
				# если не получается вытянуть телефоны, то выводим сообщение
				bot.send_message(chat_id=chat_id, text="Не удалось вытащить анкеты из базы. Надо глянуть лог", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
				return
		except Exception as e:
			bot.send_message(chat_id=chat_id, text="Не удалось взять данные из файла. Надо глянуть лог", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
			return
		tels = []
		for tel in db_profiles: # формируем список из телефонов из базы
			tels.append(tel["tel"])
		for spisok in json_data:
			new_tel = spisok["tel"].strip("+")
			if new_tel in tels:	# проверяем входит ли телефон из json файла в список телефонов из базы
				continue		# если телефон уже есть, то идет дальше по списку
			# если телефона нет в базе, то пробуем записать данные по новой анкете в базу
			if db.sql_db().insert_new_profile_from_file(spisok) is False:
				bot.send_message(chat_id=chat_id, text="Не залить данные в базу. Надо глянуть лог", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())				
				return
		bot.send_message(chat_id=chat_id, text="Данные добавлены", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())

# отправляем сообщение пользователю из админки по чат_ИД
def send_message_from_admin_chat(data):
	new_data = data.split("\n")
	try:
		text = new_data[1]
		chat_girl = new_data[0].split(" ")[1]
	except:
		return
	message_user(text=text, chat_id=chat_girl)

# выводим сообщение с анкетой при из меню девушки (ее собственная анкета)
def girl_profile_yourself(chat_id):
	profile = db.sql_db().select_profile_chat_id(chat_id) # вытаскиваем из базы данные девушки по чат_ИД
	if profile is False:
		# если в базе ничего нет, то выводим сообщение об ошибке
		bot.send_message(chat_id=chat_id, text="Хмммм... Вы уверены, что уже создали анкету?? 🤔🤔🤔", parse_mode='HTML')
		return

	create_time = profile["time"]
	if create_time is not None:
		create_time = datetime.utcfromtimestamp(create_time).strftime('%Y-%m-%d %H:%M')
	# формируем текст сообщения с анкетой
	end_text = text.text_GIRL_PROFILE.format(
		name=search_none(profile["name"]),
		age=profile["age"],
		height=profile["height"],
		weight=profile["weight"],
		hour=profile["hour"],
		night=profile["night"],
		city=search_none(profile["city"]),
		country=search_none(profile["country"]),
		edit=create_time
	)
	views = profile["views"]
	if views is None:
		views = 0
	end_text += "\nКоличество просмотров анкеты: <b>{views}</b>".format(views=views)
	if profile["foto"] is not None:			# если есть фотография, то отправляем сообщение с ней
		send_photo(chat_id, profile["foto"])
		time.sleep(0.2)
	bot.send_message(chat_id=chat_id, text=end_text, parse_mode='HTML', reply_markup=keyboard.delete_profile_keyboard())

# обработка команды "жалоба"
def commands_claim_profile(data, text, chat_id):
	# обновляем статус заявки
	db.sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
	girl_chat = data.split("_")[-1]
	end_text = "🔔Пришла жалоба на анкету, ID пользователя {chat_id} 🔔\n\n".format(chat_id=chat_id)
	end_text += text
	# уведомляем, что жалоба отправлена
	bot.send_message(chat_id=chat_id, text="Жалоба отправлена", parse_mode='HTML')
	time.sleep(0.3)
	# отправляем сообщение админу, что пришла жалоба
	message_dev(end_text)

# проверяем является ли переменная None, если нет, то делаем первую букву заглавной
def search_none(item):
	if item is not None:
		return item.title()
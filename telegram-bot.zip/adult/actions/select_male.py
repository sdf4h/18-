from adult.configs import bot
from adult.actions import delete_mes
from adult import text, keyboard, db

# добавляем нового пользователя в базу
def select_sex(data, chat, user, update_id):
	male = data.split("_")[-1]
	mes_keyboard = getattr(keyboard, 'main_keyboard_%s' % male) # нужно выбрать какую клавиатуру показать для девушки/парня
	mes_text = getattr(text, 'text_%s' % male.upper())			# тоже самое с текстом
	anketa = db.sql_db().select_user_info(chat)
	# определяем пол пользователя
	if male == 'girl':
		if anketa is False:
			mes_text = text.text_GIRL_FS
	delete_mes(chat_id=chat, mes_id=update_id)
	bot.send_message(chat_id=chat, text=mes_text, parse_mode='HTML', reply_markup=mes_keyboard(anketa))
	db.sql_db().insert_user_info_start(chat_id=chat, male=male, username=user)
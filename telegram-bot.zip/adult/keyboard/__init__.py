from telebot import types
from adult import db

#############  клавиши для админа #############
# клавиатура админки (главная, которая в самом низу)
def admin_keyboard():
	markup = types.ReplyKeyboardMarkup(one_time_keyboard=False, resize_keyboard=True)
	btn1 = types.KeyboardButton('🧠 Помощь')
	btn2 = types.KeyboardButton('Анкеты на одобрение')
	markup.add(btn1, btn2)
	return markup

# клавиатура с кнопками для бана пользователей
# появляется при запросе /ban NAME в боте
# кнопки со всеми найденными вхождениями по записям
def ban_users_keyboard(ban):
	ban_users = {}
	keyboard = types.InlineKeyboardMarkup()
	try:
		user_info = db.sql_db().select_user_info_all() # вытаскиваем из базы всех пользователей
	except:
		return False
	for user in user_info:	# формируем список пользователей, похожих на входящий аргумент
		if ban in str(user["username"]):
			ban_users.update({user["chat_id"]:user["username"]})
	if len(ban_users) == 0:	# если пользователей не найдено, то клавиатуры не будет
		return False
	for i in ban_users:
		# пишем в кнопку юзернейм
		keyboard.add(types.InlineKeyboardButton(text=ban_users[i].decode("utf-8"),callback_data="ban_{chat}".format(chat=i)))
	return keyboard

# собираем кнопки с анкетами на модерации
def profile_on_moder():
	keyboard = types.InlineKeyboardMarkup()
	profiles = db.sql_db().select_profiles_moderate() # все анкеты, у которых стоит статус 0
	if profiles is False:							  # анкеты со статусом 0 не показываются в списке анкет
		return False
	for profile in profiles:
		city = profile["city"]
		name = profile["name"]
		if name is not None:
			name = name.title()
		age = profile["age"]
		chat = profile["chat_id"]
		if chat is None:
			continue
		key_text = "{name}({age}) {city}".format(name=name, city=city, age=age)
		keyboard.add(types.InlineKeyboardButton(text=key_text,callback_data="moder_{chat}".format(chat=chat)))
	return keyboard

# клавиши под анкетой в админке (одобрить и т.д)
def moder_profile_keyboard(girl_chat):
	keyboard = types.InlineKeyboardMarkup()
	keyboard.add(types.InlineKeyboardButton(text="👍 Одобрить", callback_data="confirm_profile_{girl}".format(girl=girl_chat)))
	keyboard.add(types.InlineKeyboardButton(text="📨 Отправить сообщение", callback_data="admin_send_girl_{girl}".format(girl=girl_chat)))
	keyboard.add(types.InlineKeyboardButton(text="⬅️ назад", callback_data="back_admin_profile"))
	return keyboard

# клавиатура появляется когда приходит жалоба на анкету
def view_profile(chat):
	keyboard = types.InlineKeyboardMarkup()
	keyboard.add(types.InlineKeyboardButton(text="🔍 Посмотреть анкету",callback_data="view_profile_{chat}".format(chat=chat)))
	return keyboard  

############# конец клавиши для админа #############

# основная клавитура парня (клавиатура, которая находится снизу, под полем ввода)
def main_keyboard_boy(args):
	markup = types.ReplyKeyboardMarkup(one_time_keyboard=False, resize_keyboard=True)
	btn1 = types.KeyboardButton('🔎 Поиск девушек')
	btn2 = types.KeyboardButton('📨 Написать админу')
	btn3 = types.KeyboardButton('🔗 Сменить пол')
	markup.add(btn1)
	markup.add(btn2, btn3)
	return markup

# основная клавитура девушки (клавиатура, которая находится снизу, под полем ввода)
def main_keyboard_girl(args):
	markup = types.ReplyKeyboardMarkup(one_time_keyboard=False, resize_keyboard=True)
	text_anketa = '⚒️ Создать анкету'
	if args:
		text_anketa = '✏️ Редактировать анкету'
	btn1 = types.KeyboardButton(text_anketa)
	btn2 = types.KeyboardButton('📋 Все анкеты')
	btn3 = types.KeyboardButton('📨 Написать админу')
	btn4 = types.KeyboardButton('💟 Моя анкета')
	markup.add(btn1, btn4)
	markup.add(btn2, btn3)
	return markup

# клавиатура выбора пола
def select_sex():
	keyboard = types.InlineKeyboardMarkup()
	keyboard.add(types.InlineKeyboardButton(text="🤴 Я парень",callback_data="select_sex_boy"))
	keyboard.add(types.InlineKeyboardButton(text="👩‍💼 Я девушка",callback_data="select_sex_girl"))
	return keyboard

################ клавиатуры по поиску анкет / навигации по анкетам ######################
# поиск по стране
def search_profile_country():
	profile_country = db.sql_db().select_profile_country()
	if profile_country is False:
		return False
	keyboard = types.InlineKeyboardMarkup()
	for i in profile_country:
		country = i["country"]
		if country is None:
			continue
		count_in_country = db.sql_db().select_profile_city(country)
		text = country.title()
		if count_in_country is not False:
			text += " ({count})".format(count=len(count_in_country))
		keyboard.add(types.InlineKeyboardButton(text=text,callback_data="select_country_%s" % country))
	return keyboard

# поиск по городам
def search_profile_city(country):
	profile_city = db.sql_db().select_profile_city(country)
	if profile_city is False:
		return False
	keyboard = types.InlineKeyboardMarkup()
	for i in profile_city:
		city = i["city"]
		if city is None:
			continue
		text = city.title()
		count_in_city = db.sql_db().select_end_profile_from_city(city)
		if count_in_city is not False:
			text += " ({count})".format(count=len(count_in_city))
		keyboard.add(types.InlineKeyboardButton(text=text, callback_data="select_city_%s" % city))
	keyboard.add(types.InlineKeyboardButton(text="⬅️ назад", callback_data="back_city"))
	return keyboard

# поиск по девушкам
def search_profile_girls(city):
	profile_girls = db.sql_db().select_end_profile_from_city(city)
	if profile_girls is False:
		return False
	keyboard = types.InlineKeyboardMarkup()
	for i in profile_girls:
		girl = i["name"]
		try:
			girl = girl.title()
		except:
			pass
		chat = i["chat_id"]
		country = i["country"]
		hour = i["hour"]
		text = "♥️ {name} {price}/час".format(name=girl, price=hour)
		keyboard.add(types.InlineKeyboardButton(text=text,callback_data="select_girl_%s" % chat))
	keyboard.add(types.InlineKeyboardButton(text="⬅️ назад",callback_data="back_girls_%s" % country))
	return keyboard

# кнопки при выводе анкеты девушки при поиске анкеты девушкой/парнем
def girl_profile(girl_chat, chat_id, city):
	keyboard = types.InlineKeyboardMarkup()
	male = db.sql_db().select_user_info(chat_id)
	print(male)
	if male == False or male["male"] == "boy":
		keyboard.add(types.InlineKeyboardButton(text="Отправить девушке сообщение",callback_data="send_girl_%s" % girl_chat))
		keyboard.add(types.InlineKeyboardButton(text="Пожаловаться на девушку",callback_data="claim_girl_%s" % girl_chat))
	keyboard.add(types.InlineKeyboardButton(text="⬅️ назад",callback_data="back_profile_%s" % city))
	return keyboard

################ конец клавиатур по анкетам ######################

# Запрос телефона при создании анкеты
def get_phone():
	markup = types.ReplyKeyboardMarkup(one_time_keyboard=True, resize_keyboard=True)
	btn1 = types.KeyboardButton(text='Подтвердить телефон', request_contact=True)
	btn2 = types.KeyboardButton('❌ Отмена')
	markup.add(btn1)
	markup.add(btn2)
	return markup

# кнопки редактирования анкеты, каждая кнопка отдельный параметр
def edit_profile():
	keyboard = types.InlineKeyboardMarkup()
	keyboard.add(types.InlineKeyboardButton(text="Имя",callback_data="edit_profile_name"))
	keyboard.add(types.InlineKeyboardButton(text="Возраст",callback_data="edit_profile_age"))
	keyboard.add(types.InlineKeyboardButton(text="Рост",callback_data="edit_profile_height"))
	keyboard.add(types.InlineKeyboardButton(text="Вес",callback_data="edit_profile_weight"))
	keyboard.add(types.InlineKeyboardButton(text="Цена за час",callback_data="edit_profile_hour"))
	keyboard.add(types.InlineKeyboardButton(text="Цена за ночь",callback_data="edit_profile_night"))
	keyboard.add(types.InlineKeyboardButton(text="Город",callback_data="edit_profile_city"))
	keyboard.add(types.InlineKeyboardButton(text="Страна",callback_data="edit_profile_country"))
	keyboard.add(types.InlineKeyboardButton(text="Фото",callback_data="edit_profile_foto"))
	return keyboard

# клавиатура есть только у девушки, у которой есть анкета. Позволяет удалить анкету
def delete_profile_keyboard():
	keyboard = types.InlineKeyboardMarkup()
	keyboard.add(types.InlineKeyboardButton(text="🚫 Удалить анкету",callback_data="delete_profile"))
	return keyboard

def delete_profile_confirm_keyboard():
	keyboard = types.InlineKeyboardMarkup()
	keyboard.add(types.InlineKeyboardButton(text="✅ Да",callback_data="confirm_delete_profile"))
	keyboard.add(types.InlineKeyboardButton(text="🚫 Нет",callback_data="remove_delete_profile"))
	return keyboard

# при создании анкеты всплывает кнопка "отмена"
def cancel_keyboard():
	markup = types.ReplyKeyboardMarkup(one_time_keyboard=False, resize_keyboard=True)
	btn1 = types.KeyboardButton('❌ Отмена')
	markup.add(btn1)
	return markup
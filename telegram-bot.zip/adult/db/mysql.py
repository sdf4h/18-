import requests
import pymysql
import time
from adult.configs import *
from adult.actions import message_dev

class sql_db:
	def __init__(self):
		try:
			self.conn = pymysql.connect(
				host=adult_mysql_ip,
				user=adult_mysql_user,
				password=adult_mysql_passwd,
				db=adult_mysql_db,
				use_unicode=True,
				charset='utf8',
				cursorclass=pymysql.cursors.DictCursor)
		except pymysql.OperationalError as e: 
			print("can't find base", e)
			return False
		try:
			self.cursor = self.conn.cursor()
		except pymysql.OperationalError as e:
			print("can't get cursor", e)
			return False

	# выборка информации о пользователе по чат_ИД
	def select_user_info(self, chat_id):
		try:
			self.cursor.execute("SELECT * FROM user_info where chat_id = {chat_id}".format(chat_id=chat_id))
		except pymysql.Error:
			print("can't select_user_info", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result[0]

	# выборка информации о всех пользователей
	def select_user_info_all(self):
		try:
			self.cursor.execute("SELECT * FROM user_info")
		except pymysql.Error:
			print("can't select_user_info_all", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка данных одной анкеты по номеру телефона
	def select_profile_tel(self, tel):
		try:
			self.cursor.execute("SELECT * FROM profile where tel = '{tel}'".format(tel=tel))
		except pymysql.Error as e:
			print("can't select_profile_tel", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result[0]

	# выборка всех чат_ИД из пользовательской информации
	def select_chat_id_all(self):
		try:
			self.cursor.execute("SELECT chat_id FROM user_info")
		except pymysql.Error as e:
			print("can't select_chat_id_all", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка анкеты по чат_ИД
	def select_profile_chat_id(self, chat_id):
		try:
			self.cursor.execute("SELECT * FROM profile where chat_id = '{chat_id}'".format(chat_id=chat_id))
		except pymysql.Error as e:
			print("can't select_profile_chat_id", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result[0]

	# выборка всех анкет
	def select_profiles(self):
		try:
			self.cursor.execute("SELECT * FROM profile")
		except pymysql.Error as e:
			print("can't select_profiles", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка всех не одобренных анкет
	def select_profiles_moderate(self):
		try:
			self.cursor.execute("SELECT * FROM profile where status = 0")
		except pymysql.Error as e:
			print("can't select_profiles_moderate", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка всех телефонов
	def select_profile_telephones(self):
		try:
			self.cursor.execute("SELECT tel FROM profile")
		except pymysql.Error as e:
			print("can't select_profile_telephones", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка чат_ИД по номеру телефона
	def select_profile_by_phone(self, phone):
		try:
			self.cursor.execute("select chat_id from profile where tel = '{phone}'".format(phone=phone))
		except pymysql.Error as e:
			print("can't select_profile_by_phone", e)
			return False
		result = self.cursor.fetchone()
		if result is None:
			return False
		else: return result

	# выборка стран из анкет
	def select_profile_country(self):
		try:
			self.cursor.execute("select country from profile where status = 1 group by country")
		except pymysql.Error as e:
			print("can't select_profile_country", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка городов из анкет по фильтру СТРАНА
	def select_profile_city(self, country):
		try:
			self.cursor.execute("select city from profile where country = '{country}' and status = 1 group by city".format(country=country))
		except pymysql.Error as e:
			print("can't select_profile_city", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# выборка анкет из базы по ГОРОДУ
	def select_end_profile_from_city(self, city):
		try:
			self.cursor.execute("select * from profile where city = '{city}' and status = 1".format(city=city))
		except pymysql.Error as e:
			print("can't select_end_profile_from_city", e)
			return False
		result = self.cursor.fetchall()
		if len(result) <= 0:
			return False
		else: return result

	# обновить статус ПОЛа в базе (вдруг кто то сменит свой пол)
	def update_user_male(self, chat_id, male):
		try:
			self.cursor.execute("UPDATE user_info set male = '{male}' where chat_id='{chat_id}'".format(chat_id=chat_id, male=male))
		except pymysql.Error as e:
			print("can't update_user_male", e)
			return False
		self.conn.commit()

	# обновить параметр в информации пользователя
	def update_user_info_item(self, chat_id, item, value):
		query = "UPDATE user_info set {item} = %s where chat_id={chat}".format(item=item, chat=chat_id)
		try:
			self.cursor.execute(query, (value))
		except pymysql.Error as e:
			print("can't update_user_info_item", e)
			return False
		self.conn.commit()

	# обновить параметр в анкете по чат_ИД
	def update_profile_item(self, chat_id, item, value):
		query = "UPDATE profile set {item} = %s where chat_id={chat}".format(item=item, chat=chat_id)
		try:
			self.cursor.execute(query, (value))
		except pymysql.Error as e:
			print("can't update_profile_item", e)
			return False
		self.conn.commit()

	# обновить параметр в анкете по номеру телефона
	def update_profile_item_tel(self, tel, item, value):
		try:
			tel = tel.strip("+")
		except:
			return False
		query = "UPDATE profile set {item} = %s where tel='{tel}'".format(item=item, tel=tel)
		try:
			self.cursor.execute(query, (value))
		except pymysql.Error as e:
			print("can't update_profile_item_tel", e)
			return False
		self.conn.commit()

	# добавление новой анкеты при создании пользователем
	def insert_new_profile(self, chat_id, phone):
		try:
			self.cursor.execute("""
			INSERT INTO profile (name, chat_id, tel, hour, status, views) 
			values ('adult', {chat}, '{phone}', 0, 0, 0)""".format(chat=chat_id, phone=phone))
		except pymysql.Error as e:
			print("can't insert_new_profile", e)
			return False
		self.conn.commit()

	# добавление новых анкет из файла
	def insert_new_profile_from_file(self, data):
		keys = ["status"]
		values = [0]
		for key in data:
			if key == "foto": 									# смотрим есть ли ключ foto  в списке
				foto_bytes = get_foto_from_json(data[key])
				if foto_bytes is not False:	# если ключ есть, то пробуем стянуть картинку по указанному URL
					keys.append(key)		# если удалось стянуть картинку
					values.append(foto_bytes)	# то добавляем ключ и значение в список
					continue
			keys.append(key)
			if key == "tel":
				values.append(str(data[key]).strip("+"))
				continue
			values.append(data[key])
		try:
			add_keys = ', '.join(keys) 	# формируем список колонок
			add_values = ', '.join(['%s'] * len(values))
			query = """INSERT INTO profile (%s) values (%s)""" % (add_keys, add_values)	# формируем запрос
			self.cursor.execute(query, values) # пробуем выполнить запрос к базе - вставить данные по новой анкете
		except pymysql.Error as e:
			print("can't insert_new_profile_from_file", e)
			return False
		self.conn.commit()

	# собираем сообщение, отправленные девушкам и админам
	def insert_messages(self, user_from, user_to, message):
		message_time = int(time.time())
		try:
			self.cursor.execute("""
			INSERT INTO messages (user_from, user_to, message, timedate) 
			values ({user_from}, {user_to}, '{message}', {time})""".format(
				user_from=user_from, user_to=user_to, message=message, time=message_time))
		except pymysql.Error as e:
			print("can't insert_messages", e)
			return
		self.conn.commit()

	# добавляем нового пользователя в базу
	def insert_user_info_start(self, chat_id, male, username=0):
		user_in_base = self.select_user_info(chat_id)
		if user_in_base is not False:
			self.update_user_male(chat_id=chat_id, male=male)
			return
		try:
			self.cursor.execute("""INSERT INTO 
				user_info (chat_id, username, male, ban_status, message_status)
				values ('{chat}', '{user}', '{male}', 0, 'False')""".format(chat=chat_id, user=username, male=male))
		except pymysql.Error as e:
			message_dev("can't insert_user_info_start {chat_id} {username}".format(chat_id=chat_id, username=username))
			print("can't insert_user_info_start {chat_id} {username}\n".format(chat_id=chat_id, username=username), e)
		self.conn.commit()

	# удаляет анкету пользователя
	def sql_delete_profile(self, chat_id):
		try:
			self.cursor.execute("delete from profile where chat_id = {chat_id}".format(chat_id=chat_id))
		except pymysql.Error:
			print("can't sql_delete_profile {chat_id}".format(chat_id=chat_id))
			return False
		self.conn.commit()

# функция по стягиванию картинки по URL. Возвращает байты
def get_foto_from_json(url):
	try:
		api = requests.get(url)
		return api.content
	except:
		return False

def main():
	pass

if __name__ == "__main__":
	main()
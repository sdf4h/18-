from flask import Flask, request
import os, re, sys
import time
import yaml

from adult import text, keyboard
from adult.configs import *
from adult.actions import *
from adult.text import *
from adult.db import *

# Раскомментировать для логирования в файл
# import logging.config
# logging.config.fileConfig(os.getenv("LOG_FILE_PATH"), disable_existing_loggers=False)
# logger = logging.getLogger(__name__)
try:
	with open(admin_file, "r") as file:
		admins = yaml.safe_load(file)
except Exception as e:
	print("could not open FILE admins.yml", e)
	sys.exit(2)

server = Flask(__name__)			# инициализация Flask сервера

bot.remove_webhook()				# удаляем на всякий случай вебхук
# logger.info("delete webhook")
time.sleep(2)
									# устанавливаем вебхук на наш ИП адрес с сертификатом
bot.set_webhook(url="https://{host}:{port}".format(host=bot_ip, port=bot_port), certificate=open(cert, 'r'), allowed_updates=["message", "callback_query"])
# logger.info("set webhook %s" % bot_ip)

# в функцию приходят все запросы от телеграмма
# нам нужно только распарсить запрос и обработать
# все запросы приходят через POST
@server.route("/", methods=['POST'])
def getMessage():
	r = request.get_json()										# запрос сразу пытаемся распарсить json
	# logger.info(r)

	if r == None:
		return "ok", 200
	# return "ok", 200											# раскомментировать, если вдруг какие то ошибки или надо внести правку

	#  ФУНКЦИИ текущего блока находятся в файле actions/callback.py
	if "callback_query" in r.keys():							# если в запросе есть callback_query
		chat_id = r["callback_query"]["from"]["id"]				# то нужно вытащить chat_id
		data = r["callback_query"]["data"]						# тело сообщения
		message_id = r["callback_query"]["id"]					# на всякий случай ID сообщения
		update_id = r["callback_query"]["message"]["message_id"]
		message_date = r["callback_query"]["message"]["date"]
		username = 'Adult'
		if "username" in r["callback_query"]["from"]:			# username пользователя
			username = r["callback_query"]["from"]["username"]
				# сразу вытаскиваем инфу о пользователе из базы, если такая имеется
		# нам нужно знать пол, статус пользователя
		user_info_from_base = sql_db().select_user_info(chat_id)
		if user_info_from_base is not False:
			male = user_info_from_base["male"]
			ban_user = user_info_from_base["ban_status"]
			if ban_user == 1:
				bot.send_message(chat_id=chat_id, text=text_BAN_USER, parse_mode='HTML')				
			anketa = sql_db().select_profile_chat_id(chat_id)

		######  поиск анкет  (файл actions/callback.py функция) ######
		if "select_country_" in data:		# поиск по стране
			select_country(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "select_city_" in data:		# поиск по городу
			select_city(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "select_girl_" in data:		# поиск по девочкам
			select_girl(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "select_sex_" in data:		# выбор пола человека (парень / девушка )
			select_sex(data=data, chat=chat_id, user=username, update_id=update_id)
			return "ok", 200

		if "send_girl_" in data:		# кнопка "отправить сообщение девушке"
			send_message_to_girl(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "claim_girl_" in data:		# кнопка "пожаловаться на анкету"
			send_claim_girl(data=data, chat=chat_id)
			return "ok", 200

		if data == "delete_profile":		# кнопка "удалить анкету"
			delete_mes(chat_id=chat_id, mes_id=update_id)
			bot.send_message(chat_id=chat_id, text="Вы уверены???", parse_mode='HTML', reply_markup=keyboard.delete_profile_confirm_keyboard())
			return "ok", 200

		if data == "confirm_delete_profile":  # подтверждение удаления анкеты
			delete_mes(chat_id=chat_id, mes_id=update_id)
			if sql_db().sql_delete_profile(chat_id) is False:
				bot.send_message(chat_id=girl_chat, text=text_ERROR_COMMAND, parse_mode='HTML')
				return "ok", 200
			bot.send_message(chat_id=chat_id, text="Возвращайся. Мне будет не хватать тебя 😢", parse_mode='HTML', reply_markup=keyboard.main_keyboard_girl(False))
			return "ok", 200

		if data == "remove_delete_profile":		# отказ от удаления анкеты
			delete_mes(chat_id=chat_id, mes_id=update_id)
			bot.send_message(chat_id=chat_id, text="Ну слава Богу, а то я уж испугался 😘", parse_mode='HTML', reply_markup=keyboard.main_keyboard_girl(True))
			return "ok", 200

		if "view_profile_" in data:		# кнопка "🔍 Посмотреть анкету" из админки при жалобе
			select_girl(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "admin_send_girl_" in data and chat_id in admins["admins"]:	# кнопка "отправить сообщение девушке" из админки
			send_message_to_girl(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "moder_" in data and chat_id in admins["admins"]:	# кнопки с анкетами на модерации
			select_girl(data=data, chat=chat_id, update_id=update_id)
			return "ok", 200

		if "confirm_profile_" in data and chat_id in admins["admins"]: # одобрение анкеты
			girl_chat = data.split("_")[-1]							   # чат_ИД девушки
			delete_mes(chat_id=chat_id, mes_id=update_id)
			if sql_db().update_profile_item(chat_id=girl_chat, item="status", value=1) is not False: # пробуем обновить статус анкеты
				# если все норм, то отправляем сообщение девушке, что анкета одобрена
				bot.send_message(chat_id=girl_chat, text="Ваша анкета одобрена и появилась в поиске анкет", parse_mode='HTML')
				time.sleep(0.3)
				list_profile_for_admin(chat_id=chat_id, update_id=update_id)
			return "ok", 200

		# действие кнопки "назад" в анкете пользователя из админки
		if data == "back_admin_profile" and chat_id in admins["admins"]:
			list_profile_for_admin(chat_id=chat_id, update_id=update_id)
			return "ok", 200

		if "ban_" in data and chat_id in admins["admins"]:	# забанить пользователя
			ban_id = data.split("_")[1]
			if sql_db().update_user_info_item(chat_id=ban_id, item="ban_status", value=1) is False:
				bot.send_message(chat_id=chat_id, text="Не забанился юзер. Надо попробовать еще или глянуть лог", parse_mode='HTML')
				return "ok", 200
			bot.send_message(chat_id=chat_id, text="Пользователь успешно добавлен в бан", parse_mode='HTML')
			return "ok", 200

		if "edit_profile_" in data:		# редактирование профайла
			item = data.split("_")[-1]
			value = "edit_{item}".format(item=item)
			if item == "foto": value = "foto"
			delete_mes(chat_id=chat_id, mes_id=update_id)
			bot.send_message(chat_id=chat_id, text=update_profile[item], parse_mode='HTML')
			sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value=value)
			time.sleep(0.2)
			sql_db().update_profile_item(chat_id=chat_id, item="time", value=message_date)			
			return "ok", 200

		if "back_city" in data:			# кнопка "назад" из поиска по городам
			delete_mes(chat_id=chat_id, mes_id=update_id)
			bot.send_message(chat_id=chat_id, text="Выберите страну", parse_mode='HTML', reply_markup=keyboard.search_profile_country())
			return "ok", 200
		if "back_girls_" in data:		# кнопка "назад" из поиска по девушкам (анкетам)
			city = data.split("_")[-1]
			delete_mes(chat_id=chat_id, mes_id=update_id)
			bot.send_message(chat_id=chat_id, text="Выберете город, где вам удобно будет провести время", parse_mode='HTML', reply_markup=keyboard.search_profile_city(city))
			return "ok", 200
		if "back_profile_" in data:		# кнопка "назад" из самих анкет
			city = data.split("_")[-1]
			bot.send_message(chat_id=chat_id, text="Выберете девушку, с которой хотите встретиться и провести время", parse_mode='HTML', reply_markup=keyboard.search_profile_girls(city))
			return "ok", 200

	if "message" in r.keys():						# если в запросе на сервер прилетел Json с message
		if "chat" in r["message"]:					# проверяем есть ли чат в сообщении
			chat_id = r["message"]["chat"]["id"]
		else:
			return "ok", 200

		username = 'adult'		# если вдруг юзернейма нет, то делаем его адулт
		if "username" in r["message"]["chat"]:
			username = replace_symbols(r["message"]["chat"]["username"])
		update_id = r["update_id"]
		message_date = r["message"]["date"]

		# сразу вытаскиваем инфу о пользователе из базы, если такая имеется
		# нам нужно знать пол, статус пользователя
		user_info_from_base = sql_db().select_user_info(chat_id)
		if user_info_from_base is not False:
			male = user_info_from_base["male"]
			ban_user = user_info_from_base["ban_status"]
			if ban_user == 1:
				bot.send_message(chat_id=chat_id, text=text_BAN_USER, parse_mode='HTML')
				return "ok", 200				
			anketa = sql_db().select_profile_chat_id(chat_id)

		# подтверждение номера телефона
		if "contact" in r["message"]:
			phone = r["message"]["contact"]["phone_number"].strip("+")
			verify_telephone_number(chat_id=chat_id, phone=phone)
			return "ok", 200
		
		# смотрим пришел ли нам текст в сообщении
		if "text" in r["message"]:
			text_mess = r["message"]["text"]

			if text_mess == "/start":
				if chat_id in admins["admins"]:
					bot.send_message(chat_id=chat_id, text=text_ADMIN_MAIN, parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
					sql_db().insert_user_info_start(chat_id=chat_id, male="boy", username=username)
					return "ok", 200
				if user_info_from_base is False:
					bot.send_message(chat_id=chat_id, text=text_START.format(username=username), parse_mode='HTML', reply_markup=keyboard.select_sex())
					return "ok", 200
				mes_keyboard = getattr(keyboard, 'main_keyboard_%s' % male)
				mes_text = getattr(text, 'text_%s' % male.upper())
				if male == 'girl':
					if anketa is False:
						mes_text = text_GIRL_FS
				bot.send_message(chat_id=chat_id, text=mes_text, parse_mode='HTML', reply_markup=mes_keyboard(anketa))
				return "ok", 200

			if text_mess == "🔎 Поиск девушек" or text_mess == "📋 Все анкеты":
				country_keys = keyboard.search_profile_country()
				if country_keys is False:
					mes_keyboard = getattr(keyboard, 'main_keyboard_%s' % male)
					bot.send_message(chat_id=chat_id, text=text_ZERO_PROFILES.format(username=username), parse_mode='HTML', reply_markup=mes_keyboard(anketa))
					return "ok", 200				
				if user_info_from_base["message_status"] != "False":
					sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
				bot.send_message(chat_id=chat_id, text="Выберете страну", parse_mode='HTML', reply_markup=keyboard.search_profile_country())
				return "ok", 200

			if text_mess == "📨 Написать админу":
				bot.send_message(chat_id=chat_id, text=text_MESSAGE_TO_ADMIN, parse_mode='HTML')
				sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="admin")
				return "ok", 200

			if text_mess == "🔗 Сменить пол":
				bot.send_message(chat_id=chat_id, text=text_CHANGE_MALE, parse_mode='HTML', reply_markup=keyboard.select_sex())
				if user_info_from_base["message_status"] != "False":
					sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
				return "ok", 200

			if text_mess == "⚒️ Создать анкету":
				bot.send_message(chat_id=chat_id, text=text_VERIFY_PHONE, parse_mode='HTML', reply_markup=keyboard.get_phone())
				if user_info_from_base["message_status"] != "False":
					sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
				return "ok", 200

			if text_mess == "✏️ Редактировать анкету":
				bot.send_message(chat_id=chat_id, text=text_EDIT_PROFILE, parse_mode='HTML', reply_markup=keyboard.edit_profile())
				if user_info_from_base["message_status"] != "False":
					sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
				return "ok", 200

			# показать девушке ее собственную анкету
			if text_mess == "💟 Моя анкета":
				girl_profile_yourself(chat_id)
				return "ok", 200

			if text_mess == "❌ Отмена":
				bot.send_message(chat_id=chat_id, text=text_GIRL, parse_mode='HTML', reply_markup=keyboard.main_keyboard_girl(True))
				if user_info_from_base["message_status"] != "False":
					sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
				return "ok", 200

			# отправляем сообщение администратору (файл actions/commands.py)
			if user_info_from_base["message_status"] == "admin" and len(text_mess) != 0:
				# (файл actions/commands.py функция send_message_admin)
				send_message_admin(text_mess=text_mess, chat_id=chat_id, username=username)
				return "ok", 200

			# запрашиваем данные по одному из параметров анкеты
			if user_info_from_base["message_status"] in ["country", "city", "name", "age", "height", "weight", "hour", "night"] and len(text_mess) != 0:
				update_string_item(item=user_info_from_base["message_status"], chat_id=chat_id, value=text_mess)
				return "ok", 200

			# редактирование анкеты (один параметр)
			if "edit_" in user_info_from_base["message_status"] and len(text_mess) != 0:
				item = user_info_from_base["message_status"].split("_")[1]
				edit_profile_item(item=item, chat_id=chat_id, value=text_mess)
				return "ok", 200

			# сообщение к жалобе на анкету
			if "claim_girl_" in user_info_from_base["message_status"] and len(text_mess) != 0:
				commands_claim_profile(data=user_info_from_base["message_status"], text=text_mess, chat_id=chat_id)
				return "ok", 200

			# отправляем сообщение девушке от парня
			if "girl_" in user_info_from_base["message_status"] and len(text_mess) != 0:
				girl_chat = int(user_info_from_base["message_status"].split("_")[1])
				if chat_id in admins["admins"]:
					bot.send_message(chat_id=girl_chat, text=text_mess, parse_mode='HTML')
					sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
					return "ok", 200
				# (файл actions/commands.py функция send_message_girl)
				send_message_girl(girl_chat=girl_chat, username=username, text_mess=text_mess, chat_id=chat_id)
				sql_db().update_user_info_item(chat_id=chat_id, item="message_status", value="False")
				return "ok", 200

			if "/ban" in text_mess and chat_id in admins["admins"]:
				command_ban_user(chat_id=chat_id, data=text_mess)
				return "ok", 200

			# можно отправить пользователю сообщение из админки
			if "/send" in text_mess and chat_id in admins["admins"]:
				send_message_from_admin_chat(text_mess)
				return "ok", 200

			# можно отправить сообщение всем девушкам
			if "/all_girls" in text_mess and chat_id in admins["admins"]:
				print(1)
				message_to_all_girl(text_mess)
				return "ok", 200

			if text_mess == "🧠 Помощь" and chat_id in admins["admins"]:
				bot.send_message(chat_id=chat_id, text=text_HELP_ADMIN, parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
				return "ok", 200

			if text_mess == "Анкеты на одобрение" and chat_id in admins["admins"]:
				keys = keyboard.profile_on_moder()
				if keys is False:
					bot.send_message(chat_id=chat_id, text="Нет анкет на одобрение. Надо бы пригнать народ в бота!", parse_mode='HTML', reply_markup=keyboard.admin_keyboard())
					return "ok", 200
				bot.send_message(chat_id=chat_id, text="Если список пуст, значит он пуст!", parse_mode='HTML', reply_markup=keys)
				return "ok", 200

		# записываем загруженное фото в базу
		if user_info_from_base["message_status"] == "foto" and "photo" in r["message"]:
			photo_id = r["message"]["photo"][-1]["file_id"]
			# (файл actions/commands.py функция send_message_girl)
			update_photo(chat_id=chat_id, file_id=photo_id)
			return "ok", 200

		# функция по загрузке документа с анкетами
		if "document" in r["message"] and chat_id in admins["admins"]:
			insert_json_data(chat_id=chat_id, data=r["message"]["document"])
			return "ok", 200

	return "ok", 200

# убираем лишние символы из POST запроса к боту
def replace_symbols(text):
	update_text = re.sub(r'\W*', '', text)
	return update_text

if __name__ == "__main__":
	server.run(host=bot_ip, port=int(os.environ.get('PORT', bot_port)), ssl_context=(cert, cert_key))

import telebot
import os
from dotenv import load_dotenv

load_dotenv()

#путь до файла с настройками логов
log_ini_file = os.getenv("LOG_FILE_PATH")

#адрес бота
bot_ip = os.getenv("BOT_ADDRESS")
bot_port = os.getenv("BOT_PORT")

cert = os.getenv("CRT_FILE_PATH")
cert_key = os.getenv("CRT_FILE_KEY_PATH")

admin_file = os.getenv("ADMINS_FILE_PATH")
# mysql
adult_mysql_ip = os.getenv("MYSQL_ADDRESS")
adult_mysql_user = os.getenv("MYSQL_USER")
adult_mysql_passwd = os.getenv("MYSQL_PASSWORD")
adult_mysql_db = os.getenv("MYSQL_DATABASE")

dev_token = os.getenv("BOT_TOKEN_DEV") # токен бота для дева
bot_token = os.getenv("BOT_TOKEN") # токен бота кошелька
dev_chat_id = os.getenv("BOT_DEV_CHAT_ID") # чат_ИД разработчика

bot = telebot.TeleBot(bot_token)